import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  showOpcSelector = false;
  selectedTagLabel: string | null = null;
  selectedTagValue: string | null = null;

  onOpen() { this.showOpcSelector = true; }

  onClose() { this.showOpcSelector = false; }

  onTagSelected(payload: { name: string, value: any }) {
    this.selectedTagLabel = payload.name;
    this.selectedTagValue = payload.value;
    this.showOpcSelector = false;
  }
}
