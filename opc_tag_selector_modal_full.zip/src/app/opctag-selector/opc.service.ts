import { Injectable } from '@angular/core';
import { Observable, of, timer } from 'rxjs';
import { map } from 'rxjs/operators';
import { OpcServer, OpcItem } from './models';

@Injectable({ providedIn: 'root' })
export class OpcService {
  getServers(): Observable<OpcServer[]> {
    const data: OpcServer[] = [
      {
        id: 's1',
        name: 'Demo.OPC.Server',
        status: 'online',
        children: [
          {
            id: 'u1',
            name: 'UNIT1',
            path: 'Demo.OPC.Server/UNIT1',
            children: [
              { id: 'u1_flow', name: 'FLOW', path: 'Demo.OPC.Server/UNIT1/FLOW' },
              { id: 'u1_temp', name: 'TEMPERATURE', path: 'Demo.OPC.Server/UNIT1/TEMPERATURE' }
            ]
          },
          {
            id: 'u2',
            name: 'UNIT2',
            path: 'Demo.OPC.Server/UNIT2',
            children: [
              { id: 'u2_flow', name: 'FLOW', path: 'Demo.OPC.Server/UNIT2/FLOW' },
              { id: 'u2_temp', name: 'TEMPERATURE', path: 'Demo.OPC.Server/UNIT2/TEMPERATURE' }
            ]
          }
        ]
      }
    ];
    return timer(200).pipe(map(() => data));
  }

  getItemsForNode(nodeId: string) {
    const items: OpcItem[] = Array.from({ length: 18 }).map((_, i) => ({
      id: `${nodeId}-i${i}`,
      name: `Tag_${nodeId}_${i}`,
      type: i % 2 === 0 ? 'Analog' : 'Digital',
      unit: i % 2 === 0 ? '°C' : undefined,
      quality: ['Good', 'Bad', 'Uncertain'][i % 3],
      value: (Math.random() * 100).toFixed(2),
      description: `Simulated tag ${i} for node ${nodeId}`
    }));
    return of(items);
  }

  streamValue(itemId: string) {
    return timer(0, 1500).pipe(map(() => ({ value: (Math.random() * 100).toFixed(2), ts: new Date() })));
  }
}
