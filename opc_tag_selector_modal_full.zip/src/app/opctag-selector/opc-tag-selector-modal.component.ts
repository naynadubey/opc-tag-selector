import { Component, Input, Output, EventEmitter, OnInit, OnDestroy } from '@angular/core';
import { Subscription, BehaviorSubject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { OpcService } from './opc.service';
import { OpcServer, OpcNode, OpcItem } from './models';

@Component({
  selector: 'app-opc-tag-selector',
  templateUrl: './opc-tag-selector-modal.component.html',
  styleUrls: ['./opc-tag-selector-modal.component.scss']
})
export class OpcTagSelectorModalComponent implements OnInit, OnDestroy {
  @Input() visible = false;
  @Output() close = new EventEmitter<void>();
  @Output() tagSelect = new EventEmitter<{ name: string, value: any }>();

  servers: OpcServer[] = [];
  selectedServer?: OpcServer;
  selectedNode?: OpcNode;
  items: OpcItem[] = [];
  selectedItem?: OpcItem;

  search$ = new BehaviorSubject<string>('');
  favorites = new Set<string>();
  liveSub?: Subscription;

  private subs: Subscription[] = [];

  constructor(private opc: OpcService) {}

  ngOnInit() {
    this.subs.push(this.opc.getServers().subscribe(s => this.servers = s));

    this.subs.push(this.search$.pipe(debounceTime(180)).subscribe(term => {
      if (this.selectedNode) {
        if (!term) this.loadItems(this.selectedNode);
        else this.opc.getItemsForNode(this.selectedNode.id).subscribe(list => this.items = list.filter(it => it.name.toLowerCase().includes(term.toLowerCase())));
      }
    }));
  }

  onSelectServer(server: OpcServer) {
    this.selectedServer = server;
    this.selectedNode = undefined;
    this.items = [];
    this.selectedItem = undefined;
  }

  onSelectNode(node: OpcNode) {
    this.selectedNode = node;
    this.loadItems(node);
  }

  private loadItems(node: OpcNode) {
    this.opc.getItemsForNode(node.id).subscribe(list => this.items = list);
  }

  onSelectItem(item: OpcItem) {
    this.selectedItem = item;
    this.liveSub?.unsubscribe();
    this.liveSub = this.opc.streamValue(item.id).subscribe(update => {
      if (this.selectedItem) this.selectedItem = { ...this.selectedItem, value: update.value };
    });
  }

  toggleFavorite(item: OpcItem) {
    if (this.favorites.has(item.id)) this.favorites.delete(item.id); else this.favorites.add(item.id);
  }

  confirmSelection() {
    if (!this.selectedItem) { alert('Select a tag first'); return; }
    this.tagSelect.emit({ name: this.selectedItem.name, value: this.selectedItem.value });
  }

  closeModal() {
    this.close.emit();
  }

  ngOnDestroy() {
    this.subs.forEach(s => s.unsubscribe());
    this.liveSub?.unsubscribe();
  }
}
