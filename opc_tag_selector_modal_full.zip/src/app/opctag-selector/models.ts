export interface OpcServer {
  id: string;
  name: string;
  status: 'online' | 'offline' | 'unknown';
  children?: OpcNode[];
}

export interface OpcNode {
  id: string;
  name: string;
  path: string;
  children?: OpcNode[];
  items?: OpcItem[];
}

export interface OpcItem {
  id: string;
  name: string;
  type: string;
  unit?: string;
  quality?: 'Good' | 'Bad' | 'Uncertain';
  value?: any;
  description?: string;
}
