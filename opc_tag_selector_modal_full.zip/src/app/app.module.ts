import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { OpcTagSelectorModalComponent } from './opctag-selector/opc-tag-selector-modal.component';
import { OpcService } from './opctag-selector/opc.service';

@NgModule({
  declarations: [AppComponent, OpcTagSelectorModalComponent],
  imports: [BrowserModule, FormsModule],
  providers: [OpcService],
  bootstrap: [AppComponent]
})
export class AppModule {}
